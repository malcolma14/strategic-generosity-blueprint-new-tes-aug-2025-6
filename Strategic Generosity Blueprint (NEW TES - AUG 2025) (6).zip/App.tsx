import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "./components/ui/card";
import { Badge } from "./components/ui/badge";
import { Button } from "./components/ui/button";
import { Progress } from "./components/ui/progress";
import { Input } from "./components/ui/input";
import { StepDetailModal } from "./components/StepDetailModal";
import { 
  Compass, 
  Heart, 
  Shield, 
  TrendingUp, 
  Users, 
  Target,
  Clock,
  CheckCircle,
  ArrowRight,
  Lightbulb,
  Home,
  Download,
  Calendar,
  DollarSign,
  Building2,
  FileText,
  PieChart,
  BarChart3,
  Palette,
  BookOpen,
  Mail,
  Monitor,
  Flag,
  Lock,
  Play,
  ExternalLink,
  Info
} from "lucide-react";
import igLogo from "figma:asset/97202188247fade9486723a11ee9233edcc3dc80.png";

interface NavigationItem {
  id: string;
  label: string;
  icon: string;
  completed?: boolean;
  timeframe?: string;
  description?: string;
  isLocked?: boolean;
}

interface ValueCard {
  icon: string;
  title: string;
  subtitle: string;
  description: string;
  personalStory: string;
  color: string;
  iconComponent?: React.ReactNode;
}

interface Milestone {
  id: string;
  title: string;
  status: "completed" | "active" | "upcoming";
  date: string;
  description: string;
  icon: string;
  details?: string[];
  outcome?: string;
  color: string;
  timeframe?: string;
  whatToExpected?: string[];
  testimonial?: {
    quote: string;
    author: string;
    role: string;
  };
}

interface GenMessage {
  section: string;
  message: string;
  highlight?: string;
  keyPoints?: string[];
}

interface RealizationPhase {
  id: string;
  title: string;
  timeframe: string;
  description: string;
  value: string;
  milestones: string[];
  icon: string;
  color: string;
}

export default function App() {
  const [activeSection, setActiveSection] = useState("overview");
  const [completedSteps, setCompletedSteps] = useState(3);
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);
  const [genChatOpen, setGenChatOpen] = useState(true);
  const [hasNewHint, setHasNewHint] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [isFirstLoad, setIsFirstLoad] = useState(true);
  const [selectedStep, setSelectedStep] = useState<Milestone | null>(null);
  const [isStepModalOpen, setIsStepModalOpen] = useState(false);

  const correctPassword = "Password";

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === correctPassword) {
      setIsAuthenticated(true);
      setPasswordError("");
    } else {
      setPasswordError("Incorrect password. Please try again.");
      setPasswordInput("");
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      window.scrollTo({ top: 0, behavior: "smooth" });
      setHasNewHint(true);
    }
  }, [activeSection, isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated && isFirstLoad) {
      setIsFirstLoad(false);
    }
  }, [isAuthenticated, isFirstLoad]);

  const bookingURL =
    "https://outlook.office.com/book/AdamMalcolmConsultantIGWealthManagementOnlineBooking@igmfinancial.net/?ismsaljsauthenabled";

  // Navigation with "Your Values" unlocked, updated statuses
  const navigation: NavigationItem[] = [
    {
      id: "overview",
      label: "Overview",
      icon: "🏠",
      timeframe: "Proposal Presented",
      description: "Strategic Generosity Blueprint Proposal Presented",
      isLocked: false
    },
    {
      id: "values",
      label: "Your Values",
      icon: "💎",
      timeframe: "Proposal Presented",
      description: "Values deep dive completed",
      isLocked: false
    },
    {
      id: "blueprint",
      label: "Your SGB",
      icon: "📋",
      timeframe: "Proposal Presented",
      description: "Financial, Investment & Philanthropic strategies",
      isLocked: false
    },
    {
      id: "journey",
      label: "Your Journey",
      icon: "🗺️",
      timeframe: "Proposal Presented",
      description: "Discovery through implementation planning",
      isLocked: false
    },
    {
      id: "impact",
      label: "Impact",
      icon: "📊",
      timeframe: "Proposal Presented",
      description: "Projected legacy across all generosity dimensions",
      isLocked: false
    },
    {
      id: "advice",
      label: "Value of Advice",
      icon: "💡",
      timeframe: "Proposal Presented",
      description: "Investment breakdown and fee structure",
      isLocked: false
    },
  ];

  const valueCards: ValueCard[] = [
    {
      icon: "🎨",
      title: "Arts & Culture Passion",
      subtitle: "Your driving philanthropic focus",
      description:
        "Adrian and Kerry's deep commitment to arts and culture drives their philanthropic vision. This passion reflects their belief in the transformative power of creative expression and their desire to ensure vibrant cultural institutions remain accessible to future generations.",
      personalStory:
        "Your dedication to arts and culture creates unique opportunities for transformational giving. This foundational passion shapes your Strategic Generosity Blueprint, ensuring your $350K Smith Family DAF and 75-year giving plan creates lasting impact in the cultural sector. Your approach will strengthen arts organizations while building a meaningful family legacy.",
      color: "bg-gradient-to-br from-purple-500 to-indigo-600",
      iconComponent: <Palette className="h-12 w-12 text-white" />
    },
    {
      icon: "👨‍👩‍👧‍👦",
      title: "Family Legacy Building",
      subtitle: "Multi-generational impact focus",
      description:
        "You prioritize creating a lasting family legacy that extends beyond financial wealth. Your approach to philanthropy emphasizes values transmission and creating meaningful engagement opportunities that will inspire future generations to continue your commitment to arts and culture.",
      personalStory:
        "Your family legacy philosophy creates the perfect foundation for sustained philanthropic impact. Through your Smith Family DAF structure and 75-year giving plan, you're not just making charitable gifts—you're creating a framework for multi-generational engagement with arts and culture that will strengthen your family bonds while transforming communities.",
      color: "bg-gradient-to-br from-green-500 to-teal-600",
      iconComponent: <Flag className="h-12 w-12 text-white" />
    },
    {
      icon: "🎯",
      title: "Strategic Impact Focus",
      subtitle: "Thoughtful, purposeful giving",
      description:
        "You believe in strategic, well-planned philanthropy that creates measurable, lasting change. Rather than scattered giving, you focus on building deep relationships with arts organizations and creating sustained impact through consistent, thoughtful support over time.",
      personalStory:
        "Your strategic approach positions you for extraordinary philanthropic impact. By concentrating your giving through the Smith Family DAF model, you're able to create deeper partnerships with arts organizations, provide predictable support they can count on, and measure real impact over your 75-year giving timeline.",
      color: "bg-gradient-to-br from-orange-500 to-red-600",
      iconComponent: <Building2 className="h-12 w-12 text-white" />
    },
  ];

  // COMPLETE journey milestones - both completed and upcoming
  const milestones: Milestone[] = [
    // Completed Steps
    {
      id: "discovery",
      title: "Discovery Meeting",
      status: "completed",
      date: "June 17, 2025",
      description: "Initial goals + complexity mapping",
      icon: "🎯",
      timeframe: "90 minutes",
      details: [
        "Discussed core values and philanthropic motivations",
        "Explored current financial situation and goals", 
        "Identified arts sector passion and giving priorities",
        "Assessed current charitable giving approach",
      ],
      outcome: "Clear understanding of values-driven approach to strategic generosity established",
      color: "completed"
    },
    {
      id: "values",
      title: "Values Conversation", 
      status: "completed",
      date: "July 15, 2025",
      description: "Motivations, legacy, generosity themes",
      icon: "💎",
      timeframe: "1 hour",
      details: [
        "Explored deeper motivations for arts sector giving",
        "Discussed family legacy and values transmission",
        "Identified long-term impact goals",
        "Aligned giving strategy with personal values",
      ],
      outcome: "Strategic Generosity Blueprint anchored in authentic values and vision",
      color: "completed"
    },
    {
      id: "proposal",
      title: "Proposal Presentation",
      status: "completed", 
      date: "August 5, 2025",
      description: "Presented full strategic plan",
      icon: "📋",
      timeframe: "Strategy presentation",
      details: [
        "Financial optimization strategies presented",
        "Investment plan with ESG alignment reviewed",
        "Smith Family DAF strategy and 75-year giving plan outlined",
        "Tax optimization approach confirmed",
      ],
      outcome: "Complete strategic wealth and generosity roadmap presented and approved",
      color: "completed"
    },
    // Upcoming Steps
    {
      id: "pwpe",
      title: "PWPE Implementation",
      status: "upcoming", 
      date: "Q4 2025",
      description: "Scenario testing via Private Wealth Planning Experience",
      icon: "💼",
      timeframe: "Implementation phase",
      details: [
        "Comprehensive wealth assessment and scenario modeling",
        "Risk profile confirmation and investment objectives review",
        "Estate planning optimization and tax strategy validation",
        "Advanced planning strategies implementation",
      ],
      outcome: "Sophisticated private wealth framework fully operational",
      color: "upcoming"
    },
    {
      id: "daf-finalization",
      title: "DAF Finalization",
      status: "upcoming", 
      date: "Q4 2025",
      description: "Smith Family DAF opened + funded with $350K in-kind securities",
      icon: "🏛️",
      timeframe: "Funding phase",
      details: [
        "Smith Family DAF account opening and setup",
        "$350K in-kind securities transfer for tax efficiency",
        "75-year giving plan activation and distribution schedule",
        "Arts sector beneficiary selection and grant procedures",
      ],
      outcome: "Philanthropic vehicle fully funded and operational for long-term impact",
      color: "upcoming"
    },
    {
      id: "estate-update",
      title: "Estate Plan Update",
      status: "upcoming", 
      date: "Q1 2026",
      description: "Wills and POAs aligned with giving legacy",
      icon: "📜",
      timeframe: "Legal documentation",
      details: [
        "Wills and estate documents comprehensive update",
        "Power of Attorney documents aligned with strategy",
        "Beneficiary designations coordinated across all accounts",
        "Tax optimization strategies legally documented",
      ],
      outcome: "Complete estate plan fully aligned with strategic generosity goals",
      color: "upcoming"
    },
    {
      id: "risk-review",
      title: "Risk Management Review",
      status: "upcoming", 
      date: "Q1 2026",
      description: "Insurance and incapacity planning finalized",
      icon: "🛡️",
      timeframe: "Risk assessment",
      details: [
        "Insurance coverage comprehensive review and optimization",
        "Incapacity planning and health directive documentation",
        "Risk tolerance reassessment and portfolio alignment",
        "Emergency fund and liquidity planning confirmation",
      ],
      outcome: "Comprehensive risk management framework protecting all strategic goals",
      color: "upcoming"
    },
    {
      id: "debt-execution",
      title: "Debt Strategy Execution",
      status: "upcoming", 
      date: "Q2 2026",
      description: "Execute LOC swap and optimize tax/interest structure",
      icon: "💳",
      timeframe: "Financial restructuring",
      details: [
        "Line of credit conversion to investment loan execution",
        "Tax-deductible interest structure implementation",
        "Cash flow optimization and debt management finalization",
        "Investment strategy coordination with new debt structure",
      ],
      outcome: "Optimized debt and investment structure maximizing tax efficiency",
      color: "upcoming"
    },
  ];

  // UPDATED Adrian & Kerry Smith specific impact metrics - CORRECTED VALUES
  const impactMetrics = [
    {
      icon: "💰",
      value: "+$98,000",
      label: "Self-Generosity", 
      description: "Projected increase in personal net worth at retirement",
      tooltip: "This represents the projected improvement to your retirement net worth, a key component of living well while giving generously.",
      color: "text-blue-600",
      iconComponent: <DollarSign className="h-8 w-8" />
    },
    {
      icon: "👨‍👩‍👧‍👦",
      value: "+$1.27M",
      label: "Family Generosity",
      description: "Enhanced estate transfer and intergenerational legacy", 
      color: "text-blue-700",
      iconComponent: <Users className="h-8 w-8" />
    },
    {
      icon: "🏛️", 
      value: "+$5M",
      label: "Community Generosity",
      description: "Projected increased philanthropy compared to current plan via donation of assets, DAF strategy, and estate bequest",
      color: "text-blue-800",
      iconComponent: <Building2 className="h-8 w-8" />
    },
  ];

  // UPDATED - Complete DAF distribution data from the provided dataset
  const dafDistributionData = [
    { year: 2025, distribution: 7942.0 },
    { year: 2026, distribution: 8064.0 },
    { year: 2027, distribution: 15452.0 },
    { year: 2028, distribution: 17753.0 },
    { year: 2029, distribution: 17562.0 },
    { year: 2030, distribution: 17306.0 },
    { year: 2031, distribution: 17052.0 },
    { year: 2032, distribution: 16803.0 },
    { year: 2033, distribution: 16556.0 },
    { year: 2034, distribution: 16312.0 },
    { year: 2035, distribution: 16070.0 },
    { year: 2036, distribution: 15833.0 },
    { year: 2037, distribution: 15598.0 },
    { year: 2038, distribution: 15366.0 },
    { year: 2039, distribution: 15136.0 },
    { year: 2040, distribution: 14911.0 },
    { year: 2041, distribution: 14689.0 },
    { year: 2042, distribution: 14469.0 },
    { year: 2043, distribution: 14251.0 },
    { year: 2044, distribution: 14038.0 },
    { year: 2045, distribution: 13828.0 },
    { year: 2046, distribution: 13619.0 },
    { year: 2047, distribution: 13414.0 },
    { year: 2048, distribution: 13212.0 },
    { year: 2049, distribution: 13014.0 },
    { year: 2050, distribution: 12817.0 },
    { year: 2051, distribution: 12623.0 },
    { year: 2052, distribution: 12434.0 },
    { year: 2053, distribution: 12247.0 },
    { year: 2054, distribution: 12061.0 },
    { year: 2055, distribution: 11879.0 },
    { year: 2056, distribution: 11701.0 },
    { year: 2057, distribution: 11525.0 },
    { year: 2058, distribution: 11351.0 },
    { year: 2059, distribution: 11180.0 },
    { year: 2060, distribution: 11013.0 },
    { year: 2061, distribution: 10848.0 },
    { year: 2062, distribution: 10685.0 },
    { year: 2063, distribution: 10525.0 },
    { year: 2064, distribution: 10368.0 },
    { year: 2065, distribution: 10214.0 },
    { year: 2066, distribution: 10062.0 },
    { year: 2067, distribution: 9912.0 },
    { year: 2068, distribution: 9676.0 },
    { year: 2069, distribution: 9288.0 },
    { year: 2070, distribution: 8741.0 },
    { year: 2071, distribution: 8030.0 },
    { year: 2072, distribution: 7505.0 },
    { year: 2073, distribution: 7558.0 },
    { year: 2074, distribution: 7610.0 },
    { year: 2075, distribution: 148135.0 },
    { year: 2076, distribution: 163176.0 },
    { year: 2077, distribution: 161282.0 },
    { year: 2078, distribution: 158974.0 },
    { year: 2079, distribution: 160530.0 },
    { year: 2080, distribution: 164088.0 },
    { year: 2081, distribution: 167698.0 },
    { year: 2082, distribution: 171387.0 },
    { year: 2083, distribution: 175158.0 },
    { year: 2084, distribution: 179040.0 },
    { year: 2085, distribution: 182979.0 },
    { year: 2086, distribution: 187004.0 },
    { year: 2087, distribution: 191119.0 },
    { year: 2088, distribution: 195355.0 },
    { year: 2089, distribution: 199652.0 },
    { year: 2090, distribution: 204045.0 },
    { year: 2091, distribution: 208534.0 },
    { year: 2092, distribution: 213156.0 },
    { year: 2093, distribution: 217845.0 },
    { year: 2094, distribution: 222638.0 },
    { year: 2095, distribution: 227536.0 },
    { year: 2096, distribution: 232579.0 },
    { year: 2097, distribution: 237696.0 },
    { year: 2098, distribution: 242925.0 },
    { year: 2099, distribution: 248270.0 },
    { year: 2100, distribution: 253731.0 },
    { year: 2101, distribution: 259314.0 },
  ];

  // Value of Advice comparison data
  const adviceComparisonData = [
    { metric: "Monthly Ability", current: 15309, withAdvice: 17941 },
    { metric: "Net Estate", current: 16297692, withAdvice: 17568127 },
    { metric: "Net Worth at Retirement", current: 12830055, withAdvice: 12927611 },
    { metric: "Rate of Return", current: 5.51, withAdvice: 5.51 }
  ];

  const genMessages: Record<string, GenMessage> = {
    overview: {
      section: "overview",
      message: "Hey Adrian and Kerry! 🙋‍♀️ I'm Gen, your Strategic Generosity Blueprint guide! Congratulations on your proposal presentation - your commitment to arts sector philanthropy and strategic wealth optimization has created an incredible foundation for lasting impact! Your Smith Family DAF and 75-year giving plan represent true visionary thinking.",
      highlight: "Proposal presented! Your values-driven approach creates projected impact of $5M+ in community generosity while optimizing personal and family wealth.",
      keyPoints: [
        "✅ Proposal presentation completed August 5, 2025",
        "🎨 $350K Smith Family DAF strategy outlined", 
        "📈 +$98K personal, +$1.27M family, +$5M community generosity projected",
      ],
    },
    values: {
      section: "values",
      message: "Your values create such an authentic foundation for philanthropic success! 💙 Adrian and Kerry, your commitment to arts and culture, family legacy building, and strategic impact focus shows exactly what thoughtful philanthropy looks like. Your values alignment will guide every aspect of your Strategic Generosity Blueprint!",
      highlight: "Your authentic values create the perfect foundation for impactful arts sector giving and meaningful family legacy creation.",
      keyPoints: [
        "🎨 Arts & Culture = Deep Sector Impact",
        "👨‍👩‍👧‍👦 Family Legacy = Multi-generational Engagement",
        "🎯 Strategic Focus = Sustainable Change",
      ],
    },
    blueprint: {
      section: "blueprint", 
      message: "Your Strategic Generosity Blueprint proposal is comprehensive and exciting! 🎉 Adrian and Kerry, your integrated strategy beautifully balances financial optimization, ESG-aligned investments, and arts sector philanthropy. The DAF-first approach with your $350K Smith Family DAF creates a powerful foundation for your 75-year giving vision.",
      highlight: "Your blueprint successfully balances personal wealth optimization, family legacy building, and transformational arts sector philanthropy.",
      keyPoints: [
        "💰 Investment loan conversion optimizing tax efficiency",
        "🌱 ESG-aligned portfolio supporting values-based investing",
        "🎨 Smith Family DAF enabling strategic arts sector philanthropy",
      ],
    },
    journey: {
      section: "journey",
      message: "What an incredible discovery and implementation journey! 🗺️ From your June 2025 discovery meeting through your upcoming Q2 2026 debt optimization, you've built a comprehensive framework for strategic generosity. Your systematic approach ensures both immediate impact and long-term sustainable philanthropy in the arts sector.",
      highlight: "Your journey demonstrates how thoughtful planning leads to comprehensive implementation that creates lasting wealth optimization and cultural impact.",
      keyPoints: [
        "✅ 3 discovery steps completed successfully",
        "📅 5 implementation steps planned through Q2 2026", 
        "🎨 Comprehensive arts sector giving plan ready for execution",
      ],
    },
    impact: {
      section: "impact",
      message: "The projected impact is transformational! 🤯 Adrian and Kerry, your $5M+ community generosity projection through the arts sector, combined with $1.27M family legacy optimization, creates meaningful change across all dimensions. Your Smith Family DAF approach proves the power of strategic giving for sustained cultural impact.",
      highlight: "Your impact model creates lasting change in arts and culture while optimizing personal wealth (+$98K) and family legacy (+$1.27M).",
      keyPoints: [
        "🎨 $5M+ projected arts sector impact over 75 years",
        "👨‍👩‍👧‍👦 $1.27M family legacy optimization through estate planning",
        "💰 $98K personal wealth enhancement through strategic planning",
      ],
    },
    advice: {
      section: "advice",
      message: "Your investment in professional guidance delivers exceptional value! 💭 At 1.74% total annual cost, you're accessing comprehensive wealth management, strategic philanthropy expertise, and ongoing optimization that enables your $5M+ community impact vision while maximizing personal and family wealth outcomes.",
      highlight: "Professional guidance enables your complex strategic generosity vision while ensuring optimal financial and philanthropic outcomes across all dimensions.",
      keyPoints: [
        "📊 1.74% total annual investment for comprehensive guidance",
        "🎯 Professional support enabling $5M+ philanthropic impact", 
        "⚡ Ongoing optimization maximizing personal, family, and community outcomes",
      ],
    },
  };

  const IGLogo = ({ className = "h-8", variant = "default" }: { className?: string; variant?: "default" | "light" | "dark" }) => {
    if (variant === "light") {
      return <img src={igLogo} alt="IG Wealth Management" className={`${className} brightness-0 invert`} />;
    }
    if (variant === "dark") {
      return <img src={igLogo} alt="IG Wealth Management" className={`${className} brightness-0`} />;
    }
    return <img src={igLogo} alt="IG Wealth Management" className={className} />;
  };

  const handleBookingClick = () => {
    window.open(bookingURL, "_blank");
  };

  const handleScheduleReview = () => {
    setActiveSection("advice");
  };

  const handleNextSteps = () => {
    setActiveSection("blueprint");
  };

  const handlePDFDownload = () => {
    window.open(
      "https://drive.google.com/file/d/1LNqfDjIS3xHrtPW2QuRxZ2GS30izO6ce/view?usp=sharing",
      "_blank",
    );
  };

  const toggleGenChat = () => {
    setGenChatOpen(!genChatOpen);
    if (!genChatOpen) {
      setHasNewHint(false);
    }
  };

  const handleStepClick = (step: Milestone) => {
    setSelectedStep(step);
    setIsStepModalOpen(true);
  };

  const handleSectionChange = (sectionId: string) => {
    const section = navigation.find(item => item.id === sectionId);
    if (section && !section.isLocked) {
      setActiveSection(sectionId);
    }
  };

  // Password Protection Overlay
  const PasswordOverlay = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <IGLogo className="h-12 mx-auto mb-4" />
          <CardTitle className="text-xl">Strategic Generosity Blueprint Access</CardTitle>
          <p className="text-sm text-slate-600 mt-2">
            Please enter the password to access your personalized roadmap
          </p>
          
          {/* Desktop/Tablet Optimization Message */}
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Monitor className="h-5 w-5 text-blue-600" />
              <span className="text-sm font-semibold text-blue-900">Optimized Experience</span>
            </div>
            <p className="text-xs text-blue-800 leading-relaxed">
              This app is optimized for Desktop and Tablet. For the best experience, please access it on a larger screen.
            </p>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <div>
              <Input
                type="password"
                placeholder="Enter password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                className="w-full"
                autoFocus
              />
              {passwordError && (
                <p className="text-red-600 text-sm mt-2">{passwordError}</p>
              )}
            </div>
            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Access Blueprint
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );

  // Strategic Generosity Summary Widget - UPDATED VALUES
  const StrategicGenerositySummary = () => (
    <div className="bg-white rounded-xl border border-slate-200 shadow-lg p-8 mb-8">
      <h3 className="text-2xl font-bold text-slate-900 mb-6 text-center">Strategic Generosity Summary</h3>
      <div className="grid grid-cols-3 gap-8">
        {impactMetrics.map((metric, index) => (
          <div key={index} className="text-center relative group">
            <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
              metric.color === 'text-blue-600' ? 'bg-blue-100' : 
              metric.color === 'text-blue-700' ? 'bg-blue-200' : 
              'bg-blue-300'
            }`}>
              {metric.iconComponent}
              {metric.tooltip && (
                <div className="absolute -top-2 -right-2">
                  <Info className="h-4 w-4 text-slate-400 cursor-help" />
                </div>
              )}
            </div>
            <div className={`text-3xl font-bold mb-2 ${metric.color}`}>
              {metric.value}
            </div>
            <h4 className="font-semibold text-slate-900 mb-1">{metric.label}</h4>
            <p className="text-sm text-slate-600">{metric.description}</p>
            
            {/* Tooltip */}
            {metric.tooltip && (
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 w-64 p-3 bg-slate-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-10">
                {metric.tooltip}
                <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-slate-800 rotate-45"></div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  // Loom Welcome Video Component
  const WelcomeVideo = () => (
    <div className="mb-8">
      <div style={{ position: 'relative', paddingBottom: '56.25%', height: 0 }}>
        <iframe 
          src="https://www.loom.com/embed/1540d6c00cde4d94a58323ce17f23e9a?sid=472ac77f-9477-4c71-b93d-dc45d7b5ddc6" 
          frameBorder="0" 
          allowFullScreen 
          style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
        />
      </div>
    </div>
  );

  // Enhanced Timeline Overview Component
  const TimelineOverview = () => (
    <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 mb-8">
      <CardHeader>
        <CardTitle className="flex items-center space-x-3 text-xl">
          <CheckCircle className="h-6 w-6 text-blue-600" />
          <span>Your Strategic Generosity Blueprint - Proposal Presented</span>
        </CardTitle>
        <p className="text-slate-600 mt-2">
          <em>Discovery through proposal presentation completed successfully</em>
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4">
          {milestones.slice(0, 3).map((milestone, index) => (
            <div key={index} className="p-4 rounded-lg border-2 bg-green-50 border-green-200">
              <div className="flex items-center space-x-2 mb-2">
                <div className="p-2 rounded-full bg-green-100 text-green-600">
                  <CheckCircle className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm text-slate-900">{milestone.title}</h4>
                  <p className="text-xs text-slate-600">{milestone.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  // Enhanced Gen Chatbot
  const GenChatbot = () => {
    const currentMessage = genMessages[activeSection];

    if (!genChatOpen) {
      return (
        <div className="fixed bottom-4 right-4 z-50">
          <button
            onClick={toggleGenChat}
            className="relative w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 flex items-center justify-center group"
          >
            {hasNewHint && (
              <>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full animate-ping"></div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full"></div>
              </>
            )}

            <div className="text-white text-xl font-bold group-hover:scale-110 transition-transform">
              G
            </div>

            <div className="absolute inset-0 rounded-full bg-blue-400 animate-pulse opacity-30"></div>
            <div className="absolute -inset-2 rounded-full border-2 border-blue-400 animate-ping opacity-50"></div>
          </button>

          <div className="absolute bottom-full right-0 mb-2 px-3 py-1 bg-slate-800 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
            Hi! I&apos;m Gen, your guide 👋
          </div>
        </div>
      );
    }

    return (
      <div className="fixed bottom-4 right-4 z-50 w-80">
        <Card className="border-2 border-blue-300 bg-white shadow-xl overflow-hidden animate-slideInUp">
          <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-4 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center animate-bounce">
                  <span className="text-lg font-bold text-white">G</span>
                </div>
                <div>
                  <h4 className="text-base font-semibold text-white">Gen</h4>
                  <p className="text-xs text-blue-100">Your Strategic Guide</p>
                </div>
              </div>
              <button
                onClick={toggleGenChat}
                className="text-white/80 hover:text-white text-xl p-1"
                aria-label="Close chat"
              >
                ×
              </button>
            </div>
          </div>

          {isFirstLoad && (
            <div className="bg-blue-50 border-b border-blue-200 p-3">
              <div className="flex items-center space-x-2">
                <span className="text-blue-500 animate-bounce">📋</span>
                <p className="text-xs text-blue-800 font-medium">
                  Proposal presented! All sections now accessible for review.
                </p>
              </div>
            </div>
          )}

          <CardContent className="p-4 max-h-96 overflow-y-auto">
            {currentMessage && (
              <div className="space-y-4">
                <div className="bg-blue-50 rounded-lg p-3 border-l-4 border-blue-500">
                  <p className="text-sm text-slate-700 leading-relaxed">
                    {currentMessage.message}
                  </p>
                </div>

                {currentMessage.keyPoints && (
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
                      Key Highlights:
                    </p>
                    {currentMessage.keyPoints.map((point, index) => (
                      <div key={index} className="bg-white border border-blue-200 rounded-lg p-2">
                        <p className="text-xs text-blue-800 font-medium">{point}</p>
                      </div>
                    ))}
                  </div>
                )}

                {currentMessage.highlight && (
                  <div className="bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200 rounded-lg p-3">
                    <div className="flex items-start space-x-2">
                      <span className="text-lg">💡</span>
                      <p className="text-xs text-amber-800 font-medium leading-relaxed">
                        {currentMessage.highlight}
                      </p>
                    </div>
                  </div>
                )}

                <div className="text-center">
                  <p className="text-xs text-slate-500 mb-2">Next Meeting</p>
                  <p className="text-sm font-semibold text-blue-600">September 10, 2025 at 11:00 AM ET</p>
                  <p className="text-xs text-slate-600">Microsoft Teams</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  };

  // Fee Structure Visualization
  const FeeStructureChart = () => (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <h4 className="text-lg font-semibold text-slate-900 mb-4">Annual Fee Breakdown - 1.74% Total</h4>
      <div className="space-y-4">
        {/* Horizontal Segmented Bar */}
        <div className="relative h-12 bg-slate-100 rounded-lg overflow-hidden">
          <div className="absolute inset-0 flex">
            <div className="bg-blue-500 flex items-center justify-center text-white text-sm font-medium" style={{width: '61.5%'}}>
              Advisory 1.07%
            </div>
            <div className="bg-blue-400 flex items-center justify-center text-white text-sm font-medium" style={{width: '30.5%'}}>
              MER 0.53%
            </div>
            <div className="bg-blue-300 flex items-center justify-center text-white text-sm font-medium" style={{width: '8%'}}>
              HST 0.14%
            </div>
          </div>
        </div>
        
        {/* Fee Details */}
        <div className="grid grid-cols-3 gap-4 text-sm">
          <div className="text-center">
            <div className="w-4 h-4 bg-blue-500 rounded mx-auto mb-1"></div>
            <div className="font-semibold text-slate-900">1.07%</div>
            <div className="text-slate-600">Advisory Fees</div>
            <div className="text-xs text-slate-500 mt-1">Comprehensive planning and guidance</div>
          </div>
          <div className="text-center">
            <div className="w-4 h-4 bg-blue-400 rounded mx-auto mb-1"></div>
            <div className="font-semibold text-slate-900">0.53%</div>
            <div className="text-slate-600">MER</div>
            <div className="text-xs text-slate-500 mt-1">Investment management and oversight</div>
          </div>
          <div className="text-center">
            <div className="w-4 h-4 bg-blue-300 rounded mx-auto mb-1"></div>
            <div className="font-semibold text-slate-900">0.14%</div>
            <div className="text-slate-600">HST</div>
            <div className="text-xs text-slate-500 mt-1">Sales tax on advisory services</div>
          </div>
        </div>
      </div>
    </div>
  );

  // NEW - Value of Advice: Retirement and Estate Comparison
  const ValueOfAdviceComparison = () => {
    const formatCurrency = (value: number) => {
      if (value > 1000000) {
        return `$${(value / 1000000).toFixed(2)}M`;
      } else if (value > 1000) {
        return `$${(value / 1000).toFixed(0)}K`;
      } else {
        return `$${value.toLocaleString()}`;
      }
    };

    const formatPercent = (value: number) => `${value}%`;

    return (
      <Card className="shadow-lg mb-8">
        <CardHeader>
          <CardTitle className="flex items-center space-x-3 text-2xl">
            <BarChart3 className="h-6 w-6 text-blue-600" />
            <span>Value of Advice: Retirement and Estate Comparison</span>
            <div className="group relative">
              <Info className="h-4 w-4 text-slate-400 cursor-help" />
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 w-72 p-3 bg-slate-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-10">
                This chart compares your projected financial outcomes with and without strategic planning.
                <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-slate-800 rotate-45"></div>
              </div>
            </div>
          </CardTitle>
          <p className="text-slate-600 mt-2">
            <em>Demonstrating the tangible value of comprehensive financial planning</em>
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {adviceComparisonData.map((item, index) => (
              <div key={index} className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-slate-900">{item.metric}</h4>
                  <div className="flex space-x-4 text-sm">
                    <div className="text-slate-600">
                      Current: {item.metric === "Rate of Return" ? formatPercent(item.current) : formatCurrency(item.current)}
                    </div>
                    <div className="text-blue-600 font-semibold">
                      With Advice: {item.metric === "Rate of Return" ? formatPercent(item.withAdvice) : formatCurrency(item.withAdvice)}
                    </div>
                  </div>
                </div>
                
                <div className="relative">
                  <div className="flex h-8 bg-slate-100 rounded-lg overflow-hidden">
                    <div 
                      className="bg-slate-400 flex items-center justify-center text-white text-xs font-medium"
                      style={{ 
                        width: item.metric === "Rate of Return" ? '50%' : 
                               `${Math.min((item.current / Math.max(item.current, item.withAdvice)) * 50, 50)}%` 
                      }}
                    >
                      Current
                    </div>
                    <div 
                      className="bg-blue-500 flex items-center justify-center text-white text-xs font-medium"
                      style={{ 
                        width: item.metric === "Rate of Return" ? '50%' : 
                               `${Math.min((item.withAdvice / Math.max(item.current, item.withAdvice)) * 50 + 50, 100)}%` 
                      }}
                    >
                      With Advice
                    </div>
                  </div>
                </div>
                
                {item.withAdvice > item.current && item.metric !== "Rate of Return" && (
                  <div className="text-right">
                    <span className="text-green-600 font-semibold text-sm">
                      +{formatCurrency(item.withAdvice - item.current)} improvement
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  };

  // NEW - Updated Smith Family DAF Distribution Chart with year-by-year data
  const SmithFamilyDAFChart = () => {
    // Sample every 5th year for display readability, plus key milestone years
    const displayData = dafDistributionData.filter((_, index) => 
      index === 0 || // 2025
      index === 4 || // 2029 
      index === 9 || // 2034
      index === 19 || // 2044
      index === 29 || // 2054
      index === 39 || // 2064
      index === 49 || // 2074
      index === 50 || // 2075 (large spike)
      index === 60 || // 2085
      index === 70 || // 2095
      index === 76    // 2101
    );

    return (
      <div className="bg-white rounded-lg border border-slate-200 p-6">
        <h4 className="text-lg font-semibold text-slate-900 mb-2">Projected Community Giving via Smith Family DAF</h4>
        <p className="text-sm text-slate-600 mb-4">Based on $350K gift, annual distributions, and estate planning through 2101</p>
        <div className="space-y-4">
          {/* Chart visualization */}
          <div className="relative h-64 bg-slate-50 rounded-lg p-4">
            <div className="absolute bottom-4 left-4 right-4">
              <div className="flex items-end justify-between h-48">
                {displayData.map((dataPoint, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <div 
                      className="bg-blue-500 w-6 rounded-t"
                      style={{ height: `${Math.max((dataPoint.distribution / 260000) * 100, 2)}%` }}
                    ></div>
                    <div className="text-xs text-slate-600 mt-2 transform -rotate-45 origin-bottom-left">
                      {dataPoint.year}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="absolute top-4 left-4">
              <div className="text-sm text-slate-600">Annual Distribution ($)</div>
            </div>
            <div className="absolute top-4 right-4">
              <div className="text-sm text-slate-600">Optimal Distribution</div>
            </div>
          </div>
          
          {/* Key metrics */}
          <div className="grid grid-cols-4 gap-4 text-sm">
            <div className="text-center">
              <div className="text-xl font-bold text-blue-600">$350K</div>
              <div className="text-slate-600">Initial Gift (2025)</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-blue-600">$7.9M</div>
              <div className="text-slate-600">Total Distributed</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-blue-600">76 Years</div>
              <div className="text-slate-600">Giving Timeline</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-blue-600">100%</div>
              <div className="text-slate-600">Arts Sector</div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Show password overlay if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-50">
        <div className="blur-sm pointer-events-none">
          <header className="bg-white border-b border-slate-200 shadow-sm">
            <div className="max-w-7xl mx-auto px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <IGLogo className="h-8" />
                  <div>
                    <h1 className="text-lg text-slate-900 font-semibold">
                      Strategic Generosity Blueprint
                    </h1>
                    <p className="text-sm text-slate-600">IG Wealth Management</p>
                  </div>
                </div>
              </div>
            </div>
          </header>
          <div className="p-8">
            <Card className="max-w-2xl mx-auto">
              <CardContent className="p-8">
                <h2 className="text-2xl font-semibold mb-4">
                  Welcome to Your Strategic Generosity Blueprint
                </h2>
                <p className="text-slate-600">
                  Your personalized roadmap for comprehensive wealth planning and strategic generosity...
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
        <PasswordOverlay />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Custom CSS animations */}
      <style jsx>{`
        @keyframes slideInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes gradient-x {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes ripple {
          0% { transform: scale(0.8); opacity: 1; }
          100% { transform: scale(2.4); opacity: 0; }
        }
        .animate-slideInUp {
          animation: slideInUp 0.5s ease-out forwards;
        }
        .animate-gradient-x {
          animation: gradient-x 3s ease infinite;
          background-size: 200% 200%;
        }
        .animate-ripple {
          animation: ripple 2s infinite;
        }
        .generosity-bg {
          background-image: 
            radial-gradient(circle at 20% 50%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(16, 185, 129, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 40% 80%, rgba(139, 92, 246, 0.1) 0%, transparent 50%);
        }
      `}</style>

      {/* Enhanced Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <IGLogo className="h-10" />
              <div>
                <h1 className="text-2xl text-slate-900 font-bold">
                  Strategic Generosity Blueprint - Adrian & Kerry Smith
                </h1>
                <p className="text-base text-slate-600 mt-1">
                  <em>Proposal Presented – Ready for Implementation</em>
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-blue-50 rounded-full px-4 py-2">
                <CheckCircle className="h-4 w-4 text-blue-600" />
                <span className="text-sm text-blue-700 font-semibold">
                  Proposal Presented
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Desktop Sidebar */}
        <aside className="fixed left-0 top-[113px] bottom-0 w-72 bg-white border-r border-slate-200 flex flex-col">
          {/* Header Section */}
          <div className="flex-shrink-0 p-4 border-b border-slate-100">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                <CheckCircle className="h-3 w-3 text-white" />
              </div>
              <h3 className="text-sm font-semibold text-slate-900">Strategic Generosity Blueprint</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Proposal presented with $5M+ projected community impact
            </p>
          </div>

          {/* Navigation Section */}
          <div className="flex-1 min-h-0 overflow-y-auto">
            <nav className="p-4">
              <div className="space-y-2">
                {navigation.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleSectionChange(item.id)}
                    disabled={item.isLocked}
                    className={`w-full text-left p-3 rounded-lg transition-all duration-200 group relative ${
                      activeSection === item.id && !item.isLocked
                        ? "bg-blue-600 text-white shadow-md"
                        : item.isLocked
                        ? "opacity-50 cursor-not-allowed text-slate-400"
                        : "hover:bg-slate-100 text-slate-700 hover:text-slate-900"
                    }`}
                  >
                    <div className="flex items-center space-x-3 mb-1">
                      <span className="text-base">{item.icon}</span>
                      <span className="font-semibold text-sm">{item.label}</span>
                      {item.isLocked && (
                        <Lock className="h-3 w-3 ml-auto flex-shrink-0" />
                      )}
                    </div>
                    <div className={`text-xs opacity-75 ${
                      activeSection === item.id && !item.isLocked ? 'text-blue-100' : 
                      item.isLocked ? 'text-slate-400' : 'text-slate-600'
                    }`}>
                      <p className="font-medium">{item.timeframe}</p>
                      <p className="mt-0.5 leading-tight">{item.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </nav>
          </div>

          {/* Footer Section */}
          <div className="flex-shrink-0 p-4 border-t border-slate-200">
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-900">Proposal</span>
                <span className="text-xs font-semibold text-blue-600">
                  Presented
                </span>
              </div>
              <Progress value={100} className="h-2 mb-2" />
              <p className="text-xs text-slate-600 mb-2">
                3 discovery milestones completed
              </p>
              <div className="text-center">
                <p className="text-xs text-slate-500 mb-1">Next Meeting</p>
                <p className="text-xs font-semibold text-blue-600">September 10, 2025</p>
                <p className="text-xs text-slate-600">11:00 AM ET</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="ml-72 flex-1 p-6 generosity-bg">
          <div className="max-w-5xl mx-auto space-y-12">
            
            {/* Timeline Overview - Show on all sections */}
            <TimelineOverview />
            
            {/* Overview Section */}
            {activeSection === "overview" && (
              <div className="space-y-12">
                {/* Strategic Generosity Summary */}
                <StrategicGenerositySummary />

                {/* Welcome Video */}
                <WelcomeVideo />

                {/* Hero Card - Fixed text visibility and styling */}
                <Card className="overflow-hidden bg-gradient-to-br from-blue-600 to-indigo-700 text-white border-0 shadow-2xl">
                  <CardContent className="p-12">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-6">
                          <Badge variant="secondary" className="bg-white/20 text-white border-white/30 text-sm">
                            Proposal Presented - August 5, 2025
                          </Badge>
                        </div>
                        <h2 className="text-5xl font-bold mb-6 text-white">
                          Your Strategic Generosity Proposal is Complete!
                        </h2>
                        <p className="text-xl text-blue-100 leading-relaxed mb-6">
                          Congratulations Adrian and Kerry! Your comprehensive Strategic Generosity Blueprint proposal is complete. 
                          From your June 2025 discovery meeting through August 2025 proposal presentation, you've developed a powerful 
                          framework that projects $5M+ in arts sector impact while optimizing personal (+$98K) and family (+$1.27M) generosity.
                        </p>
                        <div className="flex space-x-4">
                          <Button
                            size="lg"
                            className="bg-white text-blue-600 hover:bg-slate-100 font-semibold min-h-[44px]"
                            onClick={() => setActiveSection("blueprint")}
                          >
                            View Your SGB
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                          <Button
                            size="lg"
                            variant="outline"
                            className="border-white text-white hover:bg-white hover:text-blue-600 font-semibold min-h-[44px]"
                            onClick={() => setActiveSection("impact")}
                          >
                            View Impact Analysis
                          </Button>
                        </div>
                      </div>

                      <div className="flex-shrink-0">
                        <div className="w-40 h-40 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center shadow-xl p-8 relative">
                          <IGLogo variant="light" className="h-20 w-auto" />
                          <div className="absolute inset-0 rounded-full bg-white/10 animate-ripple"></div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Proposal Summary */}
                <Card className="overflow-hidden shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3 text-2xl">
                      <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                        <CheckCircle className="h-5 w-5 text-white" />
                      </div>
                      <span>Proposal Presentation Complete - August 5, 2025</span>
                    </CardTitle>
                    <p className="text-slate-600 mt-2">
                      <em>Comprehensive strategic generosity proposal successfully presented</em>
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-8">
                      <div className="space-y-4">
                        <div className="space-y-4">
                          <p className="text-base text-slate-700 leading-relaxed font-semibold">
                            Key Proposal Components Presented
                          </p>
                          <div className="space-y-3">
                            <div className="flex items-start space-x-3">
                              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                              <p className="text-sm text-slate-600">$350K Smith Family DAF strategy outlined</p>
                            </div>
                            <div className="flex items-start space-x-3">
                              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                              <p className="text-sm text-slate-600">Investment loan conversion and tax optimization presented</p>
                            </div>
                            <div className="flex items-start space-x-3">
                              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                              <p className="text-sm text-slate-600">ESG-aligned portfolio and iProfile oversight proposed</p>
                            </div>
                            <div className="flex items-start space-x-3">
                              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                              <p className="text-sm text-slate-600">75-year arts sector giving plan and legacy framework</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
                        <h4 className="text-lg font-bold mb-4 text-slate-900">Next Meeting</h4>
                        <div className="space-y-3 text-sm">
                          <div className="flex justify-between">
                            <span className="text-slate-600">Date:</span>
                            <span className="font-semibold text-blue-600">September 10, 2025</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-600">Time:</span>
                            <span className="font-semibold text-blue-600">11:00 AM ET</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-600">Platform:</span>
                            <span className="font-semibold text-blue-600">Microsoft Teams</span>
                          </div>
                        </div>
                        <div className="mt-4 pt-4 border-t border-blue-200">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={handleBookingClick}
                            className="w-full bg-blue-600 text-white hover:bg-blue-700 border-blue-600"
                          >
                            <Calendar className="mr-2 h-4 w-4" />
                            Confirm Attendance
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Your Values Section - NOW UNLOCKED */}
            {activeSection === "values" && (
              <div className="space-y-12">
                <div className="text-center mb-12">
                  <h2 className="text-5xl font-bold mb-6 text-slate-900">
                    Understanding Adrian & Kerry Smith
                  </h2>
                  <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
                    <em>Your values create the foundation for meaningful philanthropic impact.</em> Your deep commitment to arts and culture, 
                    combined with your focus on family legacy and strategic giving, drives every aspect of your Strategic Generosity Blueprint. 
                    These authentic values guide your $350K Smith Family DAF and 75-year giving plan.
                  </p>
                </div>

                {/* Personal Introduction */}
                <Card className="bg-gradient-to-br from-purple-50 to-slate-50 border-purple-200 shadow-lg">
                  <CardContent className="p-10">
                    <div className="flex items-start space-x-8">
                      <div className="w-20 h-20 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
                        <Palette className="h-10 w-10 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-3xl font-bold mb-6 text-slate-900">
                          Your Values-Driven Approach to Arts Sector Philanthropy
                        </h3>
                        <div className="space-y-6 text-lg text-slate-700 leading-relaxed">
                          <p>
                            <strong>Adrian and Kerry,</strong> your commitment to arts and culture philanthropy represents a thoughtful alignment of personal 
                            passion with strategic impact. Your approach to cultural giving, combined with your desire for meaningful family legacy, 
                            creates unique opportunities for transformative community engagement and lasting sector change.
                          </p>
                          <p>
                            Your family legacy philosophy reflects a deep understanding that effective philanthropy requires both vision and strategy. 
                            Through your Smith Family DAF approach, you're creating a framework that will engage future generations while providing 
                            sustained support to arts organizations that need predictable, long-term partnerships.
                          </p>
                          <p>
                            Your strategic focus on arts and culture provides the foundation for developing a comprehensive 75-year giving plan that 
                            honors your values while maximizing impact. This authenticity will guide every aspect of your philanthropic journey, 
                            ensuring that your giving reflects your true priorities and creates the cultural transformation you seek.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Enhanced Values Cards */}
                <div className="space-y-8">
                  {valueCards.map((card, index) => (
                    <Card
                      key={index}
                      className={`overflow-hidden transition-all duration-500 hover:shadow-2xl border-slate-200 shadow-lg ${
                        hoveredCard === card.title ? "scale-[1.02] shadow-2xl" : ""
                      }`}
                      onMouseEnter={() => setHoveredCard(card.title)}
                      onMouseLeave={() => setHoveredCard(null)}
                    >
                      <CardContent className="p-0">
                        <div className="flex">
                          <div className={`w-1/3 ${card.color} p-12 flex flex-col items-center justify-center text-center`}>
                            <div className="mb-6">
                              {card.iconComponent || (
                                <span className="text-8xl text-white drop-shadow-lg">
                                  {card.icon}
                                </span>
                              )}
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-2">{card.title}</h3>
                            <p className="text-base text-white/90 font-medium italic">{card.subtitle}</p>
                          </div>
                          <div className="w-2/3 p-10">
                            <div className="mb-8">
                              <h4 className="text-xl font-bold text-slate-900 mb-4">What This Means for You</h4>
                              <p className="text-base text-slate-700 leading-relaxed">{card.description}</p>
                            </div>

                            <div className="bg-slate-50 rounded-lg p-6 border-l-4 border-blue-500">
                              <h4 className="text-lg font-bold text-slate-900 mb-3">
                                How This Shapes Your Strategic Generosity Blueprint
                              </h4>
                              <p className="text-base text-slate-600 leading-relaxed">{card.personalStory}</p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Strategic Advantage */}
                <Card className="ig-gradient text-white border-0 shadow-2xl">
                  <CardContent className="p-12">
                    <div className="text-center mb-8">
                      <IGLogo variant="light" className="h-12 mx-auto mb-6" />
                      <h3 className="text-4xl font-bold mb-6 text-white">
                        Why Your Values Create Philanthropic Advantage
                      </h3>
                      <p className="text-lg text-blue-100 max-w-2xl mx-auto mb-8">
                        <em>Your values aren&apos;t just nice to have - they&apos;re your competitive advantage in arts philanthropy</em>
                      </p>
                    </div>

                    <div className="grid grid-cols-3 gap-8">
                      {[
                        {
                          icon: <Palette className="h-8 w-8" />,
                          title: "Authentic Arts Connection",
                          description: "Your genuine passion for arts and culture creates deep credibility with cultural organizations and enables meaningful, lasting partnerships"
                        },
                        {
                          icon: <Flag className="h-8 w-8" />,
                          title: "Multi-generational Engagement", 
                          description: "Your family legacy approach ensures sustained commitment and creates opportunities for continued cultural leadership across generations"
                        },
                        {
                          icon: <Building2 className="h-8 w-8" />,
                          title: "Strategic Impact Focus",
                          description: "Your thoughtful approach to philanthropy creates predictable support that cultural organizations can build upon for transformational programming"
                        }
                      ].map((item, index) => (
                        <div key={index} className="text-center">
                          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                            {item.icon}
                          </div>
                          <h4 className="text-lg font-bold mb-3 text-white">{item.title}</h4>
                          <p className="text-sm text-blue-100 leading-relaxed">{item.description}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Your SGB Section - RESTRUCTURED WITH UPDATED LAYOUT */}
            {activeSection === "blueprint" && (
              <div className="space-y-12">
                <div className="text-center mb-12">
                  <h2 className="text-5xl font-bold mb-6 text-slate-900">
                    Your Strategic Generosity Blueprint
                  </h2>
                  <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
                    <em>Your complete strategy integrating financial optimization, ESG-aligned investments, and arts sector philanthropy.</em> 
                    The Smith Family DAF-first approach anchors all generosity planning for legacy, tax efficiency, and long-term vision.
                  </p>
                </div>

                {/* Financial Plan - NEW LAYOUT */}
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3 text-2xl">
                      <DollarSign className="h-6 w-6 text-green-600" />
                      <span>Financial Plan</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-8">
                      {/* Left side - Title and bullets */}
                      <div className="space-y-6">
                        <ul className="space-y-4">
                          <li className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-slate-700">Investment loan replaces LOC</span>
                          </li>
                          <li className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-slate-700">Sequenced drawdown: RRSP &gt; TFSA &gt; Corp</span>
                          </li>
                          <li className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-slate-700">Smith Family DAF-first legacy strategy</span>
                          </li>
                        </ul>
                      </div>
                      
                      {/* Right side - Video */}
                      <div className="space-y-4">
                        <div style={{ position: 'relative', paddingBottom: '56.25%', height: 0 }}>
                          <iframe 
                            src="https://www.loom.com/embed/c44cbf0bf271425eab4258b7e95a1a13?sid=620e3916-6264-41ef-8f48-53d068de6e2d" 
                            frameBorder="0" 
                            allowFullScreen 
                            style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
                          />
                        </div>
                        {/* Download button below video */}
                        <Button 
                          onClick={() => window.open('https://drive.google.com/file/d/1YO1xpGQOQzMlqh_IjtnXjdKPpkp-zfed/view?usp=sharing', '_blank')}
                          className="w-full bg-green-600 hover:bg-green-700 text-white"
                        >
                          <Download className="mr-2 h-4 w-4" />
                          Download Financial Plan (PDF)
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Investment Plan - NEW LAYOUT WITH UPDATED BULLETS */}
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3 text-2xl">
                      <TrendingUp className="h-6 w-6 text-blue-600" />
                      <span>Investment Plan</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-8">
                      {/* Left side - Title and bullets */}
                      <div className="space-y-6">
                        <ul className="space-y-4">
                          <li className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-slate-700">20% of investible portfolio realigned to ESG</span>
                          </li>
                          <li className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-slate-700">Introduce iProfile oversight</span>
                          </li>
                          <li className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-slate-700">Discretionary (pension-style) management</span>
                          </li>
                        </ul>
                      </div>
                      
                      {/* Right side - Video */}
                      <div className="space-y-4">
                        <div style={{ position: 'relative', paddingBottom: '56.25%', height: 0 }}>
                          <iframe 
                            src="https://www.loom.com/embed/427c062d6cad45278bf29c425fc08c05?sid=1f62004e-92a3-4d5e-abc1-f025a1b37156" 
                            frameBorder="0" 
                            allowFullScreen 
                            style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
                          />
                        </div>
                        {/* Download button below video */}
                        <Button 
                          onClick={() => window.open('https://drive.google.com/file/d/1eqZQa6Eo4dzJ-hBO_v4bWOggmGP2HFFd/view?usp=sharing', '_blank')}
                          className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                        >
                          <Download className="mr-2 h-4 w-4" />
                          Download Investment Plan (PDF)
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Philanthropic Plan - NEW LAYOUT WITH UPDATED BULLETS */}
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3 text-2xl">
                      <Heart className="h-6 w-6 text-red-600" />
                      <span>Philanthropic Plan</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-8">
                      {/* Left side - Title and bullets */}
                      <div className="space-y-6">
                        <ul className="space-y-4">
                          <li className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-slate-700">$350K gift to Smith Family DAF</span>
                          </li>
                          <li className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-slate-700">Arts-focused giving timeline to 2101</span>
                          </li>
                          <li className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-slate-700">$5M+ total projected impact</span>
                          </li>
                        </ul>
                      </div>
                      
                      {/* Right side - Video */}
                      <div className="space-y-4">
                        <div style={{ position: 'relative', paddingBottom: '56.25%', height: 0 }}>
                          <iframe 
                            src="https://www.loom.com/embed/72ddc21307644c99a24685d13e680d2a?sid=8e76f8c0-c622-4851-b42a-a86c7c0b8360" 
                            frameBorder="0" 
                            allowFullScreen 
                            style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
                          />
                        </div>
                        {/* Download button below video */}
                        <Button 
                          onClick={() => window.open('https://drive.google.com/file/d/1SP2Zg0v6qTv1z2OTanCkVYh7BhyhML1A/view?usp=sharing', '_blank')}
                          className="w-full bg-red-600 hover:bg-red-700 text-white"
                        >
                          <Download className="mr-2 h-4 w-4" />
                          Download Philanthropic Plan (PDF)
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Your Journey Section - UPDATED WITH BOTH COMPLETED AND UPCOMING */}
            {activeSection === "journey" && (
              <div className="space-y-12">
                <div className="text-center mb-12">
                  <h2 className="text-5xl font-bold mb-6 text-slate-900">
                    Your Strategic Generosity Journey
                  </h2>
                  <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
                    <em>From discovery through complete implementation - your comprehensive roadmap.</em> Your systematic approach 
                    from June 2025 discovery through Q2 2026 final implementation demonstrates how thoughtful planning creates 
                    sustainable philanthropic impact and meaningful arts sector transformation.
                  </p>
                </div>

                {/* Journey Timeline */}
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3 text-2xl">
                      <Target className="h-6 w-6 text-blue-600" />
                      <span>Complete Strategic Implementation Journey</span>
                    </CardTitle>
                    <p className="text-slate-600 mt-2">
                      <em>3 completed milestones + 5 upcoming implementation steps</em>
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="relative">
                      {/* Vertical connecting line */}
                      <div className="absolute left-10 top-0 bottom-0 w-1 bg-gradient-to-b from-green-400 via-blue-400 to-orange-400"></div>

                      <div className="space-y-8">
                        {milestones.map((milestone, index) => (
                          <div
                            key={milestone.id}
                            className="relative flex items-start space-x-8 cursor-pointer group"
                            onClick={() => handleStepClick(milestone)}
                          >
                            {/* Step icon */}
                            <div className={`relative w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold text-white shadow-lg z-10 transition-all duration-300 group-hover:scale-110 ${
                              milestone.status === "completed" ? "bg-gradient-to-br from-green-400 to-green-600" : 
                              milestone.status === "active" ? "bg-gradient-to-br from-blue-400 to-blue-600" :
                              "bg-gradient-to-br from-orange-400 to-orange-600"
                            }`}>
                              {milestone.status === "completed" ? <CheckCircle className="h-10 w-10" /> : 
                               milestone.status === "active" ? <Clock className="h-10 w-10" /> :
                               <Target className="h-10 w-10" />}
                            </div>

                            {/* Step content */}
                            <div className="flex-1 pb-8">
                              <Card className={`transition-all duration-300 group-hover:shadow-xl group-hover:scale-[1.02] ${
                                milestone.status === "completed" ? "border-green-200" : 
                                milestone.status === "active" ? "border-blue-200" :
                                "border-orange-200"
                              }`}>
                                <CardContent className="p-6">
                                  <div className="flex items-center justify-between mb-4">
                                    <div className="flex-1">
                                      <h3 className="text-xl font-bold text-slate-900 mb-2">
                                        {milestone.title}
                                      </h3>
                                      <div className="flex flex-wrap items-center space-x-3 mb-3">
                                        <Badge className={`${
                                          milestone.status === "completed" ? "bg-green-500 text-white" : 
                                          milestone.status === "active" ? "bg-blue-500 text-white" :
                                          "bg-orange-500 text-white"
                                        }`}>
                                          {milestone.date}
                                        </Badge>
                                        {milestone.timeframe && (
                                          <Badge variant="outline" className="text-slate-600">
                                            {milestone.timeframe}
                                          </Badge>
                                        )}
                                        <Badge className={`${
                                          milestone.status === "completed" ? "bg-green-500 text-white" : 
                                          milestone.status === "active" ? "bg-blue-500 text-white" :
                                          "bg-orange-500 text-white"
                                        }`}>
                                          {milestone.status === "completed" ? "Completed" : 
                                           milestone.status === "active" ? "In Progress" : "Upcoming"}
                                        </Badge>
                                      </div>
                                    </div>
                                    <ArrowRight className="h-6 w-6 text-slate-400 group-hover:text-blue-500 transition-colors flex-shrink-0" />
                                  </div>

                                  <p className="text-base text-slate-700 leading-relaxed mb-4">
                                    {milestone.description}
                                  </p>

                                  {milestone.outcome && (
                                    <div className={`rounded-lg p-4 border-l-4 mb-4 ${
                                      milestone.status === "completed" ? "bg-green-50 border-green-500" : 
                                      milestone.status === "active" ? "bg-blue-50 border-blue-500" :
                                      "bg-orange-50 border-orange-500"
                                    }`}>
                                      <h4 className={`font-semibold mb-2 ${
                                        milestone.status === "completed" ? "text-green-900" : 
                                        milestone.status === "active" ? "text-blue-900" :
                                        "text-orange-900"
                                      }`}>
                                        {milestone.status === "completed" ? "Outcome Achieved" : "Expected Outcome"}
                                      </h4>
                                      <p className={`text-sm ${
                                        milestone.status === "completed" ? "text-green-700" : 
                                        milestone.status === "active" ? "text-blue-700" :
                                        "text-orange-700"
                                      }`}>{milestone.outcome}</p>
                                    </div>
                                  )}

                                  {milestone.details && (
                                    <div className="grid grid-cols-2 gap-3">
                                      {milestone.details.map((detail, idx) => (
                                        <div key={idx} className="flex items-start space-x-2 text-sm text-slate-600">
                                          <div className={`mt-1.5 w-2 h-2 rounded-full flex-shrink-0 ${
                                            milestone.status === "completed" ? "bg-green-400" : 
                                            milestone.status === "active" ? "bg-blue-400" :
                                            "bg-orange-400"
                                          }`}></div>
                                          <span>{detail}</span>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </CardContent>
                              </Card>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Progress summary */}
                      <div className="mt-12 pt-6 border-t border-slate-200">
                        <div className="text-center">
                          <h4 className="text-xl font-bold text-slate-900 mb-3">
                            Implementation Roadmap: Discovery Complete, Implementation Ahead
                          </h4>
                          <div className="flex items-center justify-center space-x-8 mb-4">
                            <div className="text-center">
                              <div className="text-3xl font-bold text-green-600">3</div>
                              <p className="text-sm text-slate-600">Completed</p>
                            </div>
                            <div className="text-center">
                              <div className="text-3xl font-bold text-orange-600">5</div>
                              <p className="text-sm text-slate-600">Upcoming</p>
                            </div>
                            <div className="text-center">
                              <div className="text-3xl font-bold text-purple-600">18</div>
                              <p className="text-sm text-slate-600">Month Timeline</p>
                            </div>
                          </div>
                          <Progress value={37.5} className="h-3 mb-3" />
                          <p className="text-sm text-slate-500">
                            37.5% complete • Next meeting: September 10, 2025 at 11:00 AM ET via Microsoft Teams
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Impact Section - UPDATED WITH NEW COMPARISON CHART */}
            {activeSection === "impact" && (
              <div className="space-y-12">
                <div className="text-center mb-12">
                  <h2 className="text-5xl font-bold mb-6 text-slate-900">
                    Your Philanthropic Impact & Legacy
                  </h2>
                  <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
                    <em>Creating lasting arts sector transformation through strategic Smith Family DAF giving.</em> Your Smith Family DAF approach 
                    demonstrates the power of values-aligned philanthropy with comprehensive distribution strategy spanning 75+ years 
                    in Arts, Culture, and Recreation (100% sector focus).
                  </p>
                </div>

                {/* Impact Overview */}
                <Card className="ig-gradient text-white border-0 shadow-2xl">
                  <CardContent className="p-12 text-center">
                    <h3 className="text-3xl font-bold mb-6 text-white">
                      Smith Family DAF Impact Projection
                    </h3>
                    <div className="grid grid-cols-4 gap-8 mb-8">
                      <div>
                        <div className="text-4xl font-bold text-white mb-2">$350K</div>
                        <p className="text-sm text-blue-100">Initial Gift (2025)</p>
                      </div>
                      <div>
                        <div className="text-4xl font-bold text-white mb-2">76</div>
                        <p className="text-sm text-blue-100">Years Distribution Plan</p>
                      </div>
                      <div>
                        <div className="text-4xl font-bold text-white mb-2">$7.9M</div>
                        <p className="text-sm text-blue-100">Total Distribution</p>
                      </div>
                      <div>
                        <div className="text-4xl font-bold text-white mb-2">100%</div>
                        <p className="text-sm text-blue-100">Arts Sector Focus</p>
                      </div>
                    </div>
                    <p className="text-lg text-blue-100 max-w-2xl mx-auto">
                      Foundation: Smith Family DAF • Sector: Arts, Culture, Recreation • Timeline: 2025–2101
                    </p>
                  </CardContent>
                </Card>

                {/* NEW - Value of Advice Comparison replaces Generosity Outcomes */}
                <ValueOfAdviceComparison />

                {/* Smith Family DAF Distribution Chart */}
                <SmithFamilyDAFChart />
              </div>
            )}

            {/* Value of Advice Section - UPDATED */}
            {activeSection === "advice" && (
              <div className="space-y-12">
                <div className="text-center mb-12">
                  <h2 className="text-5xl font-bold mb-6 text-slate-900">
                    Value of Advice
                  </h2>
                  <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
                    <em>Your investment in comprehensive guidance delivers exceptional value.</em> At 1.74% total annual cost, 
                    you're accessing strategic wealth management, philanthropic expertise, and ongoing optimization that enables 
                    your $5M+ community impact vision while maximizing personal and family wealth outcomes.
                  </p>
                </div>

                {/* Fee Structure */}
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3 text-2xl">
                      <DollarSign className="h-6 w-6 text-green-600" />
                      <span>Value of Advice - 1.74% Total Annual Investment</span>
                    </CardTitle>
                    <p className="text-slate-600 mt-2">
                      <em>Comprehensive guidance enabling your strategic generosity vision</em>
                    </p>
                  </CardHeader>
                  <CardContent>
                    <FeeStructureChart />
                  </CardContent>
                </Card>

                {/* Value Delivered */}
                <Card className="ig-gradient text-white border-0 shadow-2xl">
                  <CardContent className="p-12">
                    <div className="text-center mb-8">
                      <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6">
                        <Lightbulb className="h-10 w-10 text-white" />
                      </div>
                      <h3 className="text-3xl font-bold mb-4 text-white">
                        Value Delivered Through Professional Guidance
                      </h3>
                      <p className="text-lg text-blue-100 mb-8 max-w-2xl mx-auto">
                        Your 1.74% annual investment enables complex strategic generosity implementation while optimizing 
                        all wealth dimensions and ensuring long-term philanthropic impact sustainability.
                      </p>
                    </div>

                    <div className="grid grid-cols-3 gap-8">
                      {[
                        {
                          icon: <Building2 className="h-8 w-8" />,
                          title: "Strategic Implementation Excellence",
                          description: "Expert execution of Smith Family DAF strategy, investment loan conversion, and ESG alignment delivering measurable results across all wealth dimensions"
                        },
                        {
                          icon: <Target className="h-8 w-8" />,
                          title: "Integrated Optimization",
                          description: "Seamless coordination between personal wealth (+$98K), family legacy (+$1.27M), and community impact (+$5M) strategies"
                        },
                        {
                          icon: <Shield className="h-8 w-8" />,
                          title: "Ongoing Value Creation",
                          description: "Continuous optimization, risk management, and strategic guidance ensuring your philanthropic vision achieves maximum sustainable impact"
                        }
                      ].map((item, index) => (
                        <div key={index} className="text-center">
                          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                            {item.icon}
                          </div>
                          <h4 className="text-lg font-bold mb-3 text-white">{item.title}</h4>
                          <p className="text-sm text-blue-100 leading-relaxed">{item.description}</p>
                        </div>
                      ))}
                    </div>

                    {/* Academic Findings Summary Box */}
                    <div className="mt-8 p-6 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
                      <h4 className="text-lg font-bold text-white mb-4">Summary: Value of Advice – Academic Findings</h4>
                      <div className="space-y-3 mb-4">
                        <div className="flex items-start space-x-3">
                          <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
                          <p className="text-sm text-blue-100 leading-relaxed">
                            Financial advisors (investment-centric) consistently underperform benchmarks after fees and often exhibit conflicts of interest.
                          </p>
                        </div>
                        <div className="flex items-start space-x-3">
                          <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
                          <p className="text-sm text-blue-100 leading-relaxed">
                            Comprehensive financial planners (especially CFP® professionals) deliver measurable client benefits through holistic planning, behavioral coaching, and improved well-being.
                          </p>
                        </div>
                        <div className="flex items-start space-x-3">
                          <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
                          <p className="text-sm text-blue-100 leading-relaxed">
                            Academic research strongly favors the comprehensive, process-focused planning model over traditional product-focused advice.
                          </p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="bg-slate-900 text-white hover:bg-slate-800 border-0"
                        onClick={handlePDFDownload}
                      >
                        <Download className="mr-2 h-3 w-3" />
                        Read the full analysis here
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

          </div>
        </main>
      </div>

      <GenChatbot />

      {/* Step Detail Modal */}
      {selectedStep && (
        <StepDetailModal
          isOpen={isStepModalOpen}
          onClose={() => setIsStepModalOpen(false)}
          step={selectedStep}
        />
      )}

      {/* Enhanced Footer */}
      <footer className="ml-72 border-t border-slate-200 bg-white">
        <div className="max-w-5xl mx-auto p-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <IGLogo className="h-10" />
              <div className="text-base">
                <p className="font-bold text-slate-900">Adam Malcolm</p>
                <p className="text-slate-600">MFA-P, CFP, RIS • IG Wealth Management</p>
                <p className="text-slate-500 text-sm">Strategic Generosity Blueprint Specialist</p>
              </div>
            </div>

            <div className="flex items-center space-x-6">
              <a
                href="mailto:adam.malcolm@ig.ca"
                className="text-blue-600 hover:text-blue-700 transition-colors font-semibold"
              >
                adam.malcolm@ig.ca
              </a>
              <div className="text-right">
                <p className="text-sm text-slate-600">Next Meeting</p>
                <p className="font-semibold text-blue-600">September 10, 2025 • 11:00 AM ET</p>
                <p className="text-xs text-slate-600">Microsoft Teams</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}